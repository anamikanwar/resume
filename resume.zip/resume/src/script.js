document.addEventListener("DOMContentLoaded", function () {
    const themeToggleButton = document.getElementById('theme-toggle');
    const body = document.body;

    // Set default theme based on user's system preferences
    const isDarkMode = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
    if (isDarkMode) {
        body.classList.add('dark-theme');
        themeToggleButton.textContent = 'Light Theme';
    }

    // Event listener for theme toggle button
    themeToggleButton.addEventListener('click', function () {
        body.classList.toggle('dark-theme');
        
        // Change the button text based on current theme
        if (body.classList.contains('dark-theme')) {
            themeToggleButton.textContent = 'Light Theme';
        } else {
            themeToggleButton.textContent = 'Dark Theme';
        }
    });

    // Trigger fade-in animation for name
    const nameElement = document.querySelector('.name');
    nameElement.classList.add('fade-in');

    // Add click event to profile picture for bounce effect
    const profilePic = document.querySelector('.profile-pic');
    profilePic.addEventListener('click', function () {
        profilePic.classList.add('bounce');

        // Remove the bounce class after animation ends to allow retriggering
        profilePic.addEventListener('animationend', function () {
            profilePic.classList.remove('bounce');
        }, { once: true }); // Ensures it runs only once per click
    });
});
